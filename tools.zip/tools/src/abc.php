<?php


$a = [2,3,2,5,1,3,3,5];

$b = array_unique($a);

$result = [];

for($i = 0; $i< sizeof($b);$i++){
    $temp_count = 0;
   for($j = 0; $j < sizeof($a);$j++){
      if($b[$i] == $a[$j]){
         $temp_count++;
      }
   }

   $result[] = array($b[$i]=>$temp_count);
}


printf($result);


?>







?>