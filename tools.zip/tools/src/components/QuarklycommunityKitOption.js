import Option from "@quarkly/community-kit/Option";
export default Option;