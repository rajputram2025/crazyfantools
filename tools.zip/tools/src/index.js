import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import QAPI from "qapi";
import 'mdb-react-ui-kit/dist/css/mdb.min.css';
import "@fortawesome/fontawesome-free/css/all.min.css";


window.QAPI = QAPI;
ReactDOM.render(<App />, document.getElementById("root"));
