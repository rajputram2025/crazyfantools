import React from 'react';
import {
  MDBCard,
  MDBCardBody,
  MDBCol,
  MDBListGroup,
  MDBListGroupItem,
  MDBRow
} from 'mdb-react-ui-kit';

export default function Bowler() {
  return (
    <MDBRow>
      <MDBCol xl={4} lg={6} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/320500/320506.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>Rashid Khan</p>
                <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>Gujarat Titans</p>
                <p className='fw-bold mb-1'>Best Figure</p>
                <p className='text-muted mb-0'>3/36</p>
              </div>
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Matches</p>
                <p className='text-muted mb-0'>11</p>
                <p className='fw-bold mb-1'>Wickets</p>
                <p className='text-muted mb-0'>10</p>
                <p className='fw-bold mb-1'>Econm</p>
                <p className='text-muted mb-0'> 6.90</p>
              </div>
            </div>
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
      <MDBCol xl={4} lg={6} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/320500/320506.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>Rashid Khan</p>
                <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>Gujarat Titans</p>
                <p className='fw-bold mb-1'>Best Figure</p>
                <p className='text-muted mb-0'>3/36</p>
              </div>
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Matches</p>
                <p className='text-muted mb-0'>11</p>
                <p className='fw-bold mb-1'>Wickets</p>
                <p className='text-muted mb-0'>10</p>
                <p className='fw-bold mb-1'>Econm</p>
                <p className='text-muted mb-0'> 6.90</p>
              </div>
            </div>
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
      <MDBCol xl={4} lg={6} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/320500/320506.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>Rashid Khan</p>
                <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>Gujarat Titans</p>
                <p className='fw-bold mb-1'>Best Figure</p>
                <p className='text-muted mb-0'>3/36</p>
              </div>
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Matches</p>
                <p className='text-muted mb-0'>11</p>
                <p className='fw-bold mb-1'>Wickets</p>
                <p className='text-muted mb-0'>10</p>
                <p className='fw-bold mb-1'>Econm</p>
                <p className='text-muted mb-0'> 6.90</p>
              </div>
            </div>
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
      <MDBCol xl={4} lg={6} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/320500/320506.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>Rashid Khan</p>
                <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>Gujarat Titans</p>
                <p className='fw-bold mb-1'>Best Figure</p>
                <p className='text-muted mb-0'>3/36</p>
              </div>
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Matches</p>
                <p className='text-muted mb-0'>11</p>
                <p className='fw-bold mb-1'>Wickets</p>
                <p className='text-muted mb-0'>10</p>
                <p className='fw-bold mb-1'>Econm</p>
                <p className='text-muted mb-0'> 6.90</p>
              </div>
            </div>
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
      <MDBCol xl={4} lg={6} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/320500/320506.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>Rashid Khan</p>
                <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>Gujarat Titans</p>
                <p className='fw-bold mb-1'>Best Figure</p>
                <p className='text-muted mb-0'>3/36</p>
              </div>
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Matches</p>
                <p className='text-muted mb-0'>11</p>
                <p className='fw-bold mb-1'>Wickets</p>
                <p className='text-muted mb-0'>10</p>
                <p className='fw-bold mb-1'>Econm</p>
                <p className='text-muted mb-0'> 6.90</p>
              </div>
            </div>
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
      <MDBCol xl={4} lg={6} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/320500/320506.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>Rashid Khan</p>
                <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>Gujarat Titans</p>
                <p className='fw-bold mb-1'>Best Figure</p>
                <p className='text-muted mb-0'>3/36</p>
              </div>
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Matches</p>
                <p className='text-muted mb-0'>11</p>
                <p className='fw-bold mb-1'>Wickets</p>
                <p className='text-muted mb-0'>10</p>
                <p className='fw-bold mb-1'>Econm</p>
                <p className='text-muted mb-0'> 6.90</p>
              </div>
            </div>
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
    </MDBRow>
  );
}