import React from 'react';
import {
  MDBCard,
  MDBCardBody,
  MDBCol,
  MDBListGroup,
  MDBListGroupItem,
  MDBRow
} from 'mdb-react-ui-kit';

export default function Listmain() {
  return (
    <MDBRow>
      <MDBCol xl={4} lg={6} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/319900/319946.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>MS Dhoni</p>
                <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>CSK</p>
                <p className='fw-bold mb-1'>Balls</p>
                <p className='text-muted mb-0'>605</p>
                <p className='fw-bold mb-1'>Sixes</p>
                <p className='text-muted mb-0'>46</p>
              </div>
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Matches</p>
                <p className='text-muted mb-0'>33</p>
                <p className='fw-bold mb-1'>Runs</p>
                <p className='text-muted mb-0'>849</p>
                <p className='fw-bold mb-1'>Strike Rate</p>
                <p className='text-muted mb-0'>140.33</p>
                <p className='fw-bold mb-1'>Fours</p>
                <p className='text-muted mb-0'>55</p>
              </div>
            </div>
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
      <MDBCol xl={4} lg={6} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/319900/319946.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>MS Dhoni</p>
                <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>CSK</p>
                <p className='fw-bold mb-1'>Balls</p>
                <p className='text-muted mb-0'>605</p>
                <p className='fw-bold mb-1'>Sixes</p>
                <p className='text-muted mb-0'>46</p>
              </div>
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Matches</p>
                <p className='text-muted mb-0'>33</p>
                <p className='fw-bold mb-1'>Runs</p>
                <p className='text-muted mb-0'>849</p>
                <p className='fw-bold mb-1'>Strike Rate</p>
                <p className='text-muted mb-0'>140.33</p>
                <p className='fw-bold mb-1'>Fours</p>
                <p className='text-muted mb-0'>55</p>
              </div>
            </div>
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
      <MDBCol xl={4} lg={6} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/319900/319946.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>MS Dhoni</p>
                <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>CSK</p>
                <p className='fw-bold mb-1'>Balls</p>
                <p className='text-muted mb-0'>605</p>
                <p className='fw-bold mb-1'>Sixes</p>
                <p className='text-muted mb-0'>46</p>
              </div>
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Matches</p>
                <p className='text-muted mb-0'>33</p>
                <p className='fw-bold mb-1'>Runs</p>
                <p className='text-muted mb-0'>849</p>
                <p className='fw-bold mb-1'>Strike Rate</p>
                <p className='text-muted mb-0'>140.33</p>
                <p className='fw-bold mb-1'>Fours</p>
                <p className='text-muted mb-0'>55</p>
              </div>
            </div>
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
      <MDBCol xl={4} lg={6} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/319900/319946.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>MS Dhoni</p>
                <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>CSK</p>
                <p className='fw-bold mb-1'>Balls</p>
                <p className='text-muted mb-0'>605</p>
                <p className='fw-bold mb-1'>Sixes</p>
                <p className='text-muted mb-0'>46</p>
              </div>
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Matches</p>
                <p className='text-muted mb-0'>33</p>
                <p className='fw-bold mb-1'>Runs</p>
                <p className='text-muted mb-0'>849</p>
                <p className='fw-bold mb-1'>Strike Rate</p>
                <p className='text-muted mb-0'>140.33</p>
                <p className='fw-bold mb-1'>Fours</p>
                <p className='text-muted mb-0'>55</p>
              </div>
            </div>
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
      <MDBCol xl={4} lg={6} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/319900/319946.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>MS Dhoni</p>
                <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>CSK</p>
                <p className='fw-bold mb-1'>Balls</p>
                <p className='text-muted mb-0'>605</p>
                <p className='fw-bold mb-1'>Sixes</p>
                <p className='text-muted mb-0'>46</p>
              </div>
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Matches</p>
                <p className='text-muted mb-0'>33</p>
                <p className='fw-bold mb-1'>Runs</p>
                <p className='text-muted mb-0'>849</p>
                <p className='fw-bold mb-1'>Strike Rate</p>
                <p className='text-muted mb-0'>140.33</p>
                <p className='fw-bold mb-1'>Fours</p>
                <p className='text-muted mb-0'>55</p>
              </div>
            </div>
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
      <MDBCol xl={4} lg={6} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/319900/319946.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>MS Dhoni</p>
                <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>CSK</p>
                <p className='fw-bold mb-1'>Balls</p>
                <p className='text-muted mb-0'>605</p>
                <p className='fw-bold mb-1'>Sixes</p>
                <p className='text-muted mb-0'>46</p>
              </div>
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Matches</p>
                <p className='text-muted mb-0'>33</p>
                <p className='fw-bold mb-1'>Runs</p>
                <p className='text-muted mb-0'>849</p>
                <p className='fw-bold mb-1'>Strike Rate</p>
                <p className='text-muted mb-0'>140.33</p>
                <p className='fw-bold mb-1'>Fours</p>
                <p className='text-muted mb-0'>55</p>
              </div>
            </div>
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
    </MDBRow>
  );
}