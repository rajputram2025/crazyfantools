import React from 'react';
import {
  MDBCard,
  MDBCardBody,
  MDBCol,
  MDBListGroup,
  MDBListGroupItem,
  MDBRow
} from 'mdb-react-ui-kit';
import Table from './Table';

export default function Matchup() {
  return (
    <MDBRow>
      <MDBCol xl={6} lg={6} sm={15} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/320500/320506.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>Rashid Khan</p>
                
              </div>
              <div className='ms-3'>
              <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>Gujarat Titans</p>
              </div>
            </div>
            <Table />
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
      <MDBCol xl={6} lg={6} sm={12} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/320500/320506.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>Rashid Khan</p>
                
              </div>
              <div className='ms-3'>
              <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>Gujarat Titans</p>
              </div>
            </div>
            <Table />
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
      <MDBCol xl={6} lg={6} sm={12} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/320500/320506.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>Rashid Khan</p>
                
              </div>
              <div className='ms-3'>
              <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>Gujarat Titans</p>
              </div>
            </div>
            <Table />
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
      <MDBCol xl={6} lg={6} sm={12} className='mb-12'>
        <MDBCard>
          <MDBCardBody>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/320500/320506.png'
                alt=''
                style={{ width: '100px', height: '100px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Name</p>
                <p className='text-muted mb-0'>Rashid Khan</p>
                
              </div>
              <div className='ms-3'>
              <p className='fw-bold mb-1'>Team</p>
                <p className='text-muted mb-0'>Gujarat Titans</p>
              </div>
            </div>
            <Table />
          </MDBCardBody>
        </MDBCard>
      </MDBCol>
    </MDBRow>
  );
}