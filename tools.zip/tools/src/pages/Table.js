import React from 'react';
import { MDBBadge, MDBBtn, MDBTable, MDBTableHead, MDBTableBody } from 'mdb-react-ui-kit';

export default function App() {
  return (
    <MDBTable align='middle' sm={10}>
      <MDBTableHead>
        <tr>
          <th scope='col'># Player Name</th>
          <th scope='col'>Runs</th>
          <th scope='col'>Balls</th>
          <th scope='col'>Dismissed</th>
        </tr>
      </MDBTableHead>
      <MDBTableBody>
        <tr>
          <td>
            <div className='d-flex align-items-center'>
              <img
                src='https://img1.hscicdn.com/image/upload/f_auto,t_ds_square_w_320,q_50/lsci/db/PICTURES/CMS/319900/319946.png'
                alt=''
                style={{ width: '45px', height: '45px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>MS Dhoni</p>
                <p className='text-muted mb-0'>CSK</p>
              </div>
            </div>
          </td>
          <td>
            <p className='fw-normal mb-1'>6</p>
          </td>
          <td>
          <p className='fw-normal mb-1'>18</p>
          </td>
          <td>
          <p className='fw-normal mb-1'>1 Time</p>
          </td>
        </tr>
        <tr>
          <td>
            <div className='d-flex align-items-center'>
              <img
                src='https://m.cricbuzz.com/a/img/v1/192x192/i1/c170670/ravindra-jadeja.jpg'
                alt=''
                style={{ width: '45px', height: '45px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Ravindra Jadeja</p>
                <p className='text-muted mb-0'>CSK</p>
              </div>
            </div>
          </td>
          <td>
            <p className='fw-normal mb-1'>6</p>
          </td>
          <td>
          <p className='fw-normal mb-1'>18</p>
          </td>
          <td>
          <p className='fw-normal mb-1'>1 Time</p>
          </td>
        </tr>
        <tr>
          <td>
            <div className='d-flex align-items-center'>
              <img
                src='https://m.cricbuzz.com/a/img/v1/192x192/i1/c170639/faf-du-plessis.jpg'
                alt=''
                style={{ width: '45px', height: '45px' }}
                className='rounded-circle'
              />
              <div className='ms-3'>
                <p className='fw-bold mb-1'>Faf Du Plessis</p>
                <p className='text-muted mb-0'>CSK</p>
              </div>
            </div>
          </td>
          <td>
            <p className='fw-normal mb-1'>6</p>
          </td>
          <td>
          <p className='fw-normal mb-1'>18</p>
          </td>
          <td>
          <p className='fw-normal mb-1'>1 Time</p>
          </td>
        </tr>
      </MDBTableBody>
    </MDBTable>
  );
}