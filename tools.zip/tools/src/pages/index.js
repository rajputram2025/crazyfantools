import React,{ useState }  from "react";
import theme from "theme";
import { Theme, Image, Box, Section, Text, Button, Structure } from "@quarkly/widgets";
import { Helmet } from "react-helmet";
import { GlobalQuarklyPageStyles } from "global-page-styles";
import { Override, Menu } from "@quarkly/components";
import * as Components from "components";
import Listmain from "./Listmain";
import Bowler from "./Bowler";
import Matchup from "./Matchup";
import Navbar from "./Navbar";
import Footer from "./Footer";
import Select from "react-select";
import {MDBBtn,MDBTypography} from "mdb-react-ui-kit";
import Carousel from 'react-bootstrap/Carousel';



export default (() => {
	const [selectedOptions, setSelectedOptions] = useState();
    
	function handleSelect(data) {
		setSelectedOptions(data);
	}

	const optionList = [
		{ value: "Chennai Super Kings", label: "Chennai Super Kings" },
		{ value: "Kolkata Knight Riders", label: "Kolkata Knight Riders" },
		{ value: "Royals Challengers Bangalore", label: "Royals Challengers Bangalore" },
		{ value: "Gujarat Titans", label: "Gujarat Titans" },
		{ value: "Lucknow Super Giants", label: "Lucknow Super Giants" },
		{ value: "Delhi Capitals", label: "Delhi Capitals" },
		{ value: "Punjab Kings", label: "Punjab Kings" },
		{ value: "Mumbai Indians", label: "Mumbai Indians" },
		{ value: "Rajasthan Royals", label: "Rajasthan Royals" },
		{ value: "Sunrisers Hyderabad", label: "Sunrisers Hyderabad" }
	  ];

	return <Theme theme={theme}>
		<GlobalQuarklyPageStyles pageUrl={"index"} />
		<Helmet>
			<title>
				Quarkly export
			</title>
			<meta name={"description"} content={"Web site created using quarkly.io"} />
			<link rel={"shortcut icon"} href={"https://uploads.quarkly.io/readme/cra/favicon-32x32.ico"} type={"image/x-icon"} />
		</Helmet>
		<Section>
			<Navbar />
		</Section>
		<Box min-width="100px" min-height="100px">
			<h1 className='mb-3 text-center' >Head To Head</h1>
		</Box>
		<Structure>
			<Override slot="Content">
				<Override slot="cell-0">
				<Select
          options={optionList}
          placeholder="Select Team"
          value={selectedOptions}
          onChange={handleSelect}
          isSearchable={true}
        />
				</Override>
				<Override slot="cell-1">
				<Select
          options={optionList}
          placeholder="Select Team"
          value={selectedOptions}
          onChange={handleSelect}
          isSearchable={true}
        />
				</Override>
				<Override slot="cell-2">
				<MDBBtn className='me-1' color='danger' >Submit</MDBBtn>
				</Override>
			</Override>
		</Structure>
		<Section padding="80px 0 80px 0">
			<Box
				display="flex"
				align-items="center"
				justify-content="center"
				flex-direction="column"
				margin="0px 0px 32px 0px"
				width="100%"
			>
            <MDBTypography tag='div' className='display-5 pb-3 mb-3 border-bottom'>Top Batsman</MDBTypography>
				
			</Box>
			<Carousel>
			<Carousel.Item>
			<Listmain />
			</Carousel.Item>
			<Carousel.Item>
			<Listmain />
			</Carousel.Item>
			</Carousel>
		</Section>
		<Section padding="0px 0 0px 0">
			<Box
				display="flex"
				align-items="center"
				justify-content="center"
				flex-direction="column"
				margin="0px 0px 0px 0px"
				width="100%"
			>
			<MDBTypography tag='div' className='display-5 pb-3 mb-3 border-bottom'>Top Bowler</MDBTypography>
			</Box>
			<Bowler />
		</Section>
		<Section padding="80px 0 80px 0">
			<Box
				display="flex"
				align-items="center"
				justify-content="center"
				flex-direction="column"
				margin="0px 0px 32px 0px"
				width="100%"
			>
		<MDBTypography tag='div' className='display-5 pb-3 mb-3 border-bottom'>Match Up</MDBTypography>

			</Box>
			<Matchup />
		</Section>
		<Section>
		<Footer />
		</Section>
	</Theme>;
});