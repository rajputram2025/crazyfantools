export default {
	"pages": {
		"root": {
			"id": "root",
			"pageUrl": "root",
			"name": "root",
			"children": [
				"640b6b98b4ef240020709484",
				"640b6b98b4ef240020709487"
			]
		},
		"640b6b98b4ef240020709484": {
			"id": "640b6b98b4ef240020709484",
			"name": "404",
			"pageUrl": "404"
		},
		"640b6b98b4ef240020709487": {
			"id": "640b6b98b4ef240020709487",
			"name": "index",
			"pageUrl": "index"
		}
	},
	"mode": "production",
	"projectType": "create-react-app",
	"site": {
		"styles": {},
		"seo": {}
	}
}